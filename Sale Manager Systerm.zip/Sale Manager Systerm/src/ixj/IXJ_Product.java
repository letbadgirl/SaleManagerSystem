/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ixj;

import data.Product;
import org.w3c.dom.Document;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
//import javax.swing.text.Document;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author Trung
 */
public class IXJ_Product {
    
    public static Document document = null;
    public static DocumentBuilderFactory documentBuilderFactory = null;
    public static DocumentBuilder documentBuilder = null;
    static String urlFile = "src/data/product.xml";
    
    public static Document openDocument() {
        documentBuilderFactory = DocumentBuilderFactory.newInstance();
        try {
            documentBuilder = documentBuilderFactory.newDocumentBuilder();
            document = documentBuilder.parse(urlFile);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(IXJ_Product.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
            Logger.getLogger(IXJ_Product.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(IXJ_Product.class.getName()).log(Level.SEVERE, null, ex);
        }
        return document;
    }
    
    public static boolean Tranformer() {
        boolean b = false;
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        try {
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");// Show xml version
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");//can dong, tu can dong trong xml
            transformer.transform(new DOMSource(document), new StreamResult(urlFile));
            b = true;
        } catch (TransformerConfigurationException ex) {
            Logger.getLogger(IXJ_Product.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerException ex) {
            Logger.getLogger(IXJ_Product.class.getName()).log(Level.SEVERE, null, ex);
        }
        return b;
    }
    
    public static void creat(Product product, Element element) {
        Element Productt = document.createElement("Product");
        
        Productt.setAttribute("pro_code", product.getPro_code());
        Element pro_name = document.createElement("pro_name");
        pro_name.setTextContent(product.getPro_name());
        Element quantity = document.createElement("quantity");
        quantity.setTextContent(String.valueOf(product.getQuantity()));
        Element saled = document.createElement("saled");
        saled.setTextContent(String.valueOf(product.getSaled()));
        Element price = document.createElement("price");
        price.setTextContent(String.valueOf(product.getPrice()));
        
        Productt.appendChild(pro_name);
        Productt.appendChild(quantity);
        Productt.appendChild(saled);
        Productt.appendChild(price);
        element.appendChild(Productt);
    }
    
    public static void AddProduct(String pro_code, String pro_name, int quantity, int saled, float price) {
        openDocument();
        Element element = document.getDocumentElement();//Lay the goc trong file xml
        //them product
        creat(new Product(pro_code, pro_name, quantity, saled, price), element);
        
    }
    
    public static void UpdateProduct(String pro_code, String pro_name, int quantity, int saled, float price) {
        //update dont edit pro_code
        openDocument();
        NodeList nodeList = document.getElementsByTagName("Product");
        for (int i = 0; i < nodeList.getLength(); i++) {
            NodeList nodeChild = nodeList.item(i).getChildNodes();
            if (nodeList.item(i).getAttributes().getNamedItem("pro_code").getTextContent().trim().equals(pro_code.trim())) {
                nodeChild.item(1).setTextContent(pro_name);
                nodeChild.item(3).setTextContent(String.valueOf(quantity));
                nodeChild.item(5).setTextContent(String.valueOf(saled));
                nodeChild.item(7).setTextContent(String.valueOf(price));
            }
        }
    }
    
    public static void DeleteProduct(String pro_code){
        openDocument();
        NodeList nodeList = document.getElementsByTagName("Product");
        Element element = document.getDocumentElement();
        for (int i = 0; i < nodeList.getLength(); i++) {
            //so sanh pro_code neu giong thi xoa
            if(nodeList.item(i).getAttributes().getNamedItem("pro_code").getTextContent().trim().equals(pro_code)){
                element.removeChild(nodeList.item(i));
            }
        }
    }
    
}
