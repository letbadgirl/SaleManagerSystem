/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ixj;

import data.Customer;
import static ixj.IXJ_Product.document;
import static ixj.IXJ_Product.urlFile;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

/**
 *
 * @author Trung
 */
public class IXJ_Customer {

    public static Document document = null;
    public static DocumentBuilderFactory documentBuilderFactory = null;
    public static DocumentBuilder documentBuilder = null;
    static String urlFile = "src/data/customer.xml";

    public static Document openDocument() {
        documentBuilderFactory = DocumentBuilderFactory.newInstance();
        try {
            documentBuilder = documentBuilderFactory.newDocumentBuilder();
            document = documentBuilder.parse(urlFile);
        } catch (ParserConfigurationException ex) {
            Logger.getLogger(IXJ_Customer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SAXException ex) {
            Logger.getLogger(IXJ_Customer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(IXJ_Customer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return document;
    }

    public static boolean Tranformer() {
        boolean b = false;
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        try {
            Transformer transformer = transformerFactory.newTransformer();
            transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "no");// Show xml version
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");//can dong, tu can dong trong xml
            transformer.transform(new DOMSource(document), new StreamResult(urlFile));
            b = true;
        } catch (TransformerConfigurationException ex) {
            Logger.getLogger(IXJ_Customer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (TransformerException ex) {
            Logger.getLogger(IXJ_Customer.class.getName()).log(Level.SEVERE, null, ex);
        }
        return b;
    }
    
    public static void creat(Customer c, Element e){
        Element cus = document.createElement("Customer");
        
        cus.setAttribute("cus_code", c.getCus_code());
        Element cus_name = document.createElement("cus_name");
        cus_name.setTextContent(c.getCus_name());
        Element phone = document.createElement("phone");
        phone.setTextContent(c.getPhone());
        
        cus.appendChild(cus_name);
        cus.appendChild(phone);
        e.appendChild(cus);
    }
    
    public static void AddCustomer(String cus_code, String cus_name, String phone){
        openDocument();
        Element e = document.getDocumentElement();
        
        creat(new Customer(cus_code, cus_name, phone), e);
        
    }
    
    public static void UpdateCustomer(String cus_code, String cus_name, String phone){
        openDocument();
        NodeList nodeList = document.getElementsByTagName("Customer");
        for (int i = 0; i < nodeList.getLength(); i++) {
            NodeList nodeChild = nodeList.item(i).getChildNodes();
            if(nodeList.item(i).getAttributes().getNamedItem("cus_code").getTextContent().trim().equals(cus_code.trim())){
                nodeChild.item(1).setTextContent(cus_name);
                nodeChild.item(3).setTextContent(phone);
            }
        }
    }
    
    public static void DeleteCustomer(String cus_code){
        openDocument();
        NodeList nodeList = document.getElementsByTagName("Customer");
        Element e = document.getDocumentElement();
        for (int i = 0; i < nodeList.getLength(); i++) {
            if(nodeList.item(i).getAttributes().getNamedItem("cus_code").getTextContent().trim().equals(cus_code)){
                e.removeChild(nodeList.item(i));
            }
        }
    }
}
