/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

/**
 *
 * @author Trung
 */
public class Ordering {

    private String pro_code;
    private String cus_code;
    private int quantity;
    private float total;

    public String getPro_code() {
        return pro_code;
    }

    public void setPro_code(String pro_code) {
        this.pro_code = pro_code;
    }

    public String getCus_code() {
        return cus_code;
    }

    public void setCus_code(String cus_code) {
        this.cus_code = cus_code;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public float getTotal() {
        return total;
    }

    public void setTotal(float total) {
        this.total = total;
    }

    public Ordering(String pro_code, String cus_code, int quantity, float total) {
        this.pro_code = pro_code;
        this.cus_code = cus_code;
        this.quantity = quantity;
        this.total = total;
    }

    public Ordering() {

    }
}
