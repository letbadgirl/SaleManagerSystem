/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package data;

/**
 *
 * @author Trung
 */
public class Customer {

    private String cus_code;
    private String cus_name;
    private String phone;

    public String getCus_code() {
        return cus_code;
    }

    public void setCus_code(String cus_code) {
        this.cus_code = cus_code;
    }

    public String getCus_name() {
        return cus_name;
    }

    public void setCus_name(String cus_name) {
        this.cus_name = cus_name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public Customer(String cus_code, String cus_name, String phone) {
        this.cus_code = cus_code;
        this.cus_name = cus_name;
        this.phone = phone;
    }

    public Customer() {

    }
}
